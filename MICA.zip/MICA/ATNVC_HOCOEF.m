function ATNVC_HOCOEF
clc
clear
global NApath
global CBFpath
global HO_map
global Outputpath
global output_name

datafdir=CBFpath;
dataddir=NApath;
listm=dir([datafdir,filesep,'*.nii']);
listh=dir([HO_map,filesep,'*.nii']);
listn=dir([dataddir,filesep,'*.nii']);
outputdir = Outputpath
o = output_name
h = []
for j = 1:length(listh);
    HO=[HO_map,filesep,listh(j).name];
volmask=spm_vol(HO);
imgmask=spm_read_vols(volmask);
imgmask = imgmask>1;
%imgmask(isnan(imgmask))=0;
cd(datafdir)
     for k=1:length(listm);
    subjname=listm(k).name;
    vol_cbf=spm_vol([datafdir,filesep,subjname]);
    img_cbf=spm_read_vols(vol_cbf);
    %img_cbf(isnan(img_cbf))=0;
    img_cbf=double(img_cbf).*double(imgmask);
    a=img_cbf;
   cd(dataddir);
    subjnamed=subjname;
    vol_dc=spm_vol([dataddir,filesep,subjnamed]);
    img_dc=spm_read_vols(vol_dc);
    %img_cbf(isnan(img_cbf))=0;
    img_dc=double(img_dc).*double(imgmask);
     b=img_dc;
     coef = corrcoef(a,b);
    coe = coef(2,1);
  
    h(k,j) = coe;
    cd(datafdir);
    disp(['Calculating the coupling value in ROI_',mat2str(i),'-subject_',mat2str(s)]);
      end
end
cd(outputdir)
xlswrite(['HO_',o,'.xlsx'],h)
disp('The analysis was successfully conducted');
