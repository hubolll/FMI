
function map_extract
clc
clear
global diy_PathName
global diy_outpath
global diy_FileName
templ = [diy_PathName,filesep,diy_FileName];
templa = spm_vol(templ);
templat = spm_read_vols(templa);
outdir = diy_outpath;
mkdir(outdir);
non_inf = templat;
non_inf(find(non_inf == Inf)) = 0;
non_inf(find(non_inf == -Inf)) = 0;
non_inf(isnan(non_inf)) = 0;
non_inf = unique(non_inf);
non_inf(find(non_inf == 0)) = [];
[m,n] = size(non_inf); 

for i = 1:m
    current_roi = non_inf(i);
  templat(find(templat ~= current_roi)) = 0;
   c = templat;
   vol_zcbf = templa;
 jj = sprintf('%04d',i);
    vol_zcbf.fname=[outdir,filesep,jj,'.nii'];
    vol_zcbf.dt=[64,0];
  
disp(['writting',jj,]);
    templat = templat/current_roi;
    spm_write_vol(vol_zcbf,templat);
    templ = [diy_PathName,filesep,diy_FileName];
templa = spm_vol(templ);
templat = spm_read_vols(templa);

end